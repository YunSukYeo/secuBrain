#ifndef __CONSTANTS__
#define __CONSTANTS__


#define bool int
#define true 1
#define false 0

#define SFF_INTERFACE "sff0"
#define NSF_INTERFACE "eth0"
#define BUF_LEN 128


#endif
