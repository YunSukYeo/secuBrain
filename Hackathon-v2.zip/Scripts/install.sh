sudo apt-get install mysql-server
sudo apt-get install libmysqlclient-dev
