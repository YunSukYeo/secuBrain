/*********************************************************************
 * ConfD Subscriber intro example
 * Implements a configuration data provider
 *
 * (C) 2005-2007 Tail-f Systems
 * Permission to use this code as a starting point hereby granted
 *
 * See the README file for more information
 ********************************************************************/
#include "test.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/poll.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#include <confd_lib.h>
#include <confd_dp.h>
#include "hst.h"
#include "dlist.h"

#define bool short
#define true 1
#define false 0


/********************************************************************/

struct host {
    char rule_name[256];		// ID
	int rule_id;
	struct in_addr ip_of_staff[50];
	int staff_num;
	struct in_addr blocking_website[50];
	int website_num;
	char start_time[10];
	char end_time[10];
    bool permit;
	bool deny;
	Dlist *ifaces;
};

/********************************************************************/

/* A structure to keep tabs on how many times */
/* we access the different cb functions */
/* to show in the CLI */

struct access_stat {
    int get_elem;
    int get_next;
    int num_instances;
    int set_elem;
    int create;
    int remove;
};

static struct access_stat hcp_calls;

static Dlist *running_db = NULL;

/* Our daemon context as a global variable */
static struct confd_daemon_ctx *dctx;

static struct confd_trans_cbs trans;
static struct confd_db_cbs dbcbs;
static struct confd_data_cbs host_cbks, iface_cbks;

static int read_stdin = 1;

/* My user data, we got to install opaque data into */
/* the confd_daemon_ctx, this data is then accesible from the */
/* trans callbacks and must thus not necessarily vae to  */
/* be global data. */

struct mydata {
    int ctlsock;
    int workersock;
    int locked;
};

/********************************************************************/


//////////////////IMTL CODE//////////////////////////////////////

static void processPacket(uint8_t *data, int dataLen, int protocol) {
	    if(protocol != TUNNELING_PROTOCOL) return;

	    int ipHeaderLen = sizeof(struct iphdr);
	    struct iphdr *ipheader = (struct iphdr *) (data + ipHeaderLen); /* After outter IP header */
	    printIPHeader(ipheader);
	    ///////////////conduct inspection //////////////////////////
		
		int metadataNum = 0;
		int resultHeaderLen = (2 /*resultCode(1) + metadataNum(1)*/ + metadataNum ) * sizeof(uint8_t);
		int packetLen = ipHeaderLen + resultHeaderLen + (dataLen - ipHeaderLen);

		uint8_t *packet = (uint8_t *)malloc(packetLen);
		uint8_t metadataCodes[1] = {DDOS_INSPECTION};

		/* Attach our header & outter trunneling header */
		attach_outter_encapsulation(packet, FIREWALL_IP, SFF_IP, TUNNELING_PROTOCOL, packetLen);
		attach_inspection_result((packet + ipHeaderLen), DENY, metadataNum, metadataCodes);
		memcpy((void *)(packet + ipHeaderLen + resultHeaderLen), (void *)(data + ipHeaderLen), dataLen - ipHeaderLen); //Deteach IP Header of outter encapsulation in data 

		/* Send inspection result packet to SFF */
		sendPacket(packet); 

		free(packet);
}

/////////////////////////////////////////////////////////////////
//
static void *Thread_processPacket(void *p) {
	char* ch = (char*) p;
	start_listening(ch, &processPacket);
}
///////////////////////////////////////////////////////////////////



static void show_host(Dlist *hptr)		//Show IP lists
{
    struct host* hp = (struct host*) hptr->val;
	int num = 0;
	if(hp->permit == true) {
		printf("	%s	   %d	      %s",
				hp->rule_name, hp->rule_id, inet_ntoa(hp->ip_of_staff[num])); 
		printf("     %s	  	   %s	           %s            Permit\n",inet_ntoa(hp->blocking_website[0]), hp->start_time, hp->end_time);
		for(num = 1; num < hp->staff_num; num++) {
			printf("				      %s\n",inet_ntoa(hp->ip_of_staff[num]));
		}
	}else if(hp->deny == true) {
		printf("	%s	   %d	      %s",
				hp->rule_name, hp->rule_id, inet_ntoa(hp->ip_of_staff[num])); 
		printf("     %s	  	   %s	           %s           Deny\n",inet_ntoa(hp->blocking_website[0]), hp->start_time, hp->end_time);
		for(num = 1; num < hp->staff_num; num++) {
			printf("				      %s\n",inet_ntoa(hp->ip_of_staff[num]));
		}
	}
}

/* Help function which allocates a new host struct */
static struct host *new_host(char *name, char *permit, char *src_IP)
{
    struct host *hp;
    if ((hp = (struct host*) calloc(1, sizeof(struct host))) == NULL)
        return NULL;
    //strcpy(hp->rule_name, name);
    //strcpy(hp->permit, permit);
    //hp->blacklist[0].s_addr = inet_addr(src_IP);

    hp->ifaces = new_dlist();
    return hp;
}

/* Help function which adds a new host, keeping the list ordered */
static void add_host(Dlist *list, struct host *new)
{
    Dlist *ptr;
    struct host *hp;

    dl_traverse(ptr, list) {
        hp = (struct host *) ptr->val;
        if (strcmp(new->rule_name, hp->rule_name) < 0) {
            break;
        }
    }
    dl_insert_b(ptr, new);
}

static void show_db(Dlist *list)
{
    Dlist *hptr;
	printf ("	Rule Name	Rule ID		Title	Blocking Website	Start Time	End Time	Action\n");
	//IMTL- With this method, we can access all object of hosts
    for (hptr = list->flink; hptr != list; hptr = hptr->flink) {
        show_host(hptr);
    }
}

/* Find a specific host in a specific DB */

static Dlist *find_host(Dlist *list, confd_value_t *v)
{
    Dlist *hptr;
    for (hptr = list->flink; hptr != list; hptr = hptr->flink) {
        struct host *s = (struct host*) hptr->val;
        if (confd_svcmp(s->rule_name, v) == 0)
            return hptr;
    }
    return NULL;
}

/********************************************************************/
/* transaction callbacks  */

/* The installed init() function gets called everytime Confd */
/* wants to establish a new transaction, Each NETCONF */
/* command will be a transaction */

/* We can choose to create threads here or whatever, we */
/* can choose to allocate this transaction to an already existing */
/* thread. We must tell Confd which filedescriptor should be */
/* used for all future communication in this transaction */
/* this has to be done through the call confd_trans_set_fd(); */

static int tr_init(struct confd_trans_ctx *tctx)
{
    char buf[INET6_ADDRSTRLEN];
    inet_ntop(tctx->uinfo->af, &tctx->uinfo->ip, buf, sizeof(buf));
    printf ("s_init() for %s from %s ", tctx->uinfo->username, buf);
    struct mydata *md = (struct mydata*) tctx->dx->d_opaque;
    confd_trans_set_fd(tctx, md->workersock);
    return CONFD_OK;
}

/* This callback gets invoked at the end of the transaction */
/* when ConfD has accumulated all write operations */
/* we're guaranteed that */
/* a) no more read ops will occur */
/* b) no other transactions will run between here and tr_finish() */
/*    for this transaction, i.e ConfD will serialize all transactions */

/* since we need to be prepared for abort(), we may not write */
/* our data to the actual database, we can choose to either */
/* copy the entire database here and write to the copy in the */
/* following write operatons _or_ let the write operations */
/* accumulate operations create(), set(), delete() instead of actually */
/* writing */

/* If our db supports transactions (which it doesn't in this */
/* silly example, this is the place to do START TRANSACTION */

static int tr_writestart(struct confd_trans_ctx *tctx)
{
    return CONFD_OK;
}

static int tr_prepare(struct confd_trans_ctx *tctx)
{
    return CONFD_OK;
}

static int tr_commit(struct confd_trans_ctx *tctx) // use the xml files.
{
    struct confd_tr_item *item = tctx->accumulated; // item is dats about xml files.
    struct host *hp;
	int i = 0;
    Dlist *dlist;


    while (item) {
        confd_hkeypath_t *keypath = item->hkp;
        confd_value_t *leaf = &(keypath->v[0][0]);
		confd_value_t *list_of_staff;
		confd_value_t *list_of_website;

        if (strcmp(item->callpoint, "hcp") == 0) {
            switch (item->op) {
            case C_SET_ELEM:
				printf("\nC_SET_ELEM\n");//Debug
				if ((dlist = find_host(running_db,
                                       &(keypath->v[1][0]))) != NULL){
					hp = (struct host*) dlist->val;
					switch (CONFD_GET_XMLTAG(leaf)) { //according to leafs
					case nsc_rule_id:
						hp->rule_id = (int) CONFD_GET_UINT32(item->val);
						break;
                    default:
                        break;
                    }
				} else if ((dlist = find_host(running_db,&(keypath->v[4][0]))) != NULL){
                    hp = (struct host*) dlist->val;
                    switch (CONFD_GET_XMLTAG(leaf)) { //according to leafs

					case nsc_pkt_sec_cond_ipv4_src_addr:
						list_of_staff = CONFD_GET_LIST(item->val);
						hp->staff_num = CONFD_GET_LISTSIZE(item->val);

						for(i = 0; i < hp->staff_num; i++)
							hp->ip_of_staff[i] = CONFD_GET_IPV4(&list_of_staff[i]);
						break;

					case nsc_pkt_sec_cond_ipv4_dest_addr:
						list_of_website = CONFD_GET_LIST(item->val);
						hp->website_num = CONFD_GET_LISTSIZE(item->val);

						for(i = 0; i < hp->website_num; i++){
							hp->blocking_website[i] = CONFD_GET_IPV4(&list_of_website[i]);
							printf("%s\n",inet_ntoa(hp->blocking_website[i]));
						}
						break;

					case nsc_start_time:
						strcpy(hp->start_time, (char*) CONFD_GET_BUFPTR(item->val));
						break;

					case nsc_end_time:
						strcpy(hp->end_time, (char*) CONFD_GET_BUFPTR(item->val));
						break;

					case nsc_permit:
						hp->permit =  CONFD_GET_BOOL(item->val);
						break;

					case nsc_deny:
						hp->deny = CONFD_GET_BOOL(item->val);
						break;
                    default:
                        break;
                    }
                }
                break;
            case C_CREATE:
				printf("\nC_CREATE\n");
                hp = (struct host*) calloc(1, sizeof(struct host));
                strcpy(hp->rule_name, (char *)CONFD_GET_BUFPTR(leaf));
				hp->staff_num = 0;
			    hp->ifaces = new_dlist();
                add_host(running_db, hp);
                break;
            case C_REMOVE:
                if ((dlist = find_host(running_db, leaf)) != NULL) {
                    hp = (struct host*) dlist->val;
                    free(hp);
                    dl_delete_node(dlist);
                }
                break;
            default:
                return CONFD_ERR;
            }
        }
        item = item->next;
    }

    return CONFD_OK;
}

static int tr_abort(struct confd_trans_ctx *tctx)
{
    return CONFD_OK;
}

static int tr_finish(struct confd_trans_ctx *tctx)
{
    return CONFD_OK;
}

/********************************************************************/

/* help function which restores a DB from a FILE* */
/* also used by the "load" cmd in the CLI */

static Dlist *restore(char *fname)
{
    char buf[BUFSIZ];
    char *sep = " \r\n";
    FILE *fp;
    if ((fp  = fopen(fname, "r")) == NULL)
        return NULL;
    Dlist *list = new_dlist();

    while (fgets(&buf[0], BUFSIZ, fp) != NULL) {
        char *name, *permit, *src_IP;
        char *ip, *mask, *enabled;
        if ((name = strtok(buf, sep)) != NULL &&
            ((permit = strtok(NULL, sep)) != NULL) &&
            ((src_IP = strtok(NULL, sep)) != NULL)) {
            struct host *hp = new_host(name, permit, src_IP);

            // eath the curly brace //
            assert(strcmp(strtok(NULL, sep), "{") == 0);
            while (((name =    strtok(NULL, sep)) != NULL) &&
                   ((ip =      strtok(NULL, sep)) != NULL) &&
                   ((mask =    strtok(NULL, sep)) != NULL) &&
                   ((enabled = strtok(NULL, sep)) != NULL)) {
            }
            dl_append(list, hp);
        }
    }
    fclose(fp);
    return list;
}

/********************************************************************/
/* DB callbacks */

static int lock(struct confd_db_ctx *dbx, enum confd_dbname dbname)
{
    struct mydata *md = (struct mydata*) dbx->dx->d_opaque;
    md->locked = 1;
    return CONFD_OK;
}

static int unlock(struct confd_db_ctx *dbx, enum confd_dbname dbname)
{
    struct mydata *md = (struct mydata*) dbx->dx->d_opaque;
    md->locked = 0;
    return CONFD_OK;
}

static int delete_config(struct confd_db_ctx *dbx,
                         enum confd_dbname dbname)
{
    confd_db_seterr(dbx, "error from c");
    return CONFD_ERR;
}
static int  del_checkpoint_running  (struct confd_db_ctx *dbx)
{
    unlink("RUNNING.ckp");
    return CONFD_OK;
}

static int activate_checkpoint_running (struct confd_db_ctx *dbx)
{
    Dlist *list;
    if ((list = restore("RUNNING.ckp")) == NULL)
        return CONFD_ERR;
   // clear_db(running_db);
    running_db = list;
    return CONFD_OK;
}

/********************************************************************/
/* data callbacks that manipulate the db */

/* keypath tells us the path choosen down the XML tree */
/* We need to return a list of all server keys here */

static int reteof(struct confd_trans_ctx *tctx)
{
    confd_data_reply_next_key(tctx, NULL, -1, -1);
    return CONFD_OK;
}

static int host_get_next(struct confd_trans_ctx *tctx,
                         confd_hkeypath_t *keypath,
                         long next)
{
    confd_value_t v;
    Dlist *list;
    struct host *hp;
    hcp_calls.get_next++;
    if (next == -1 && !dl_empty(running_db)) {  /* Get first key */
        Dlist *first = dl_first(running_db);
        hp = (struct host*) first->val;
        CONFD_SET_STR(&v, hp->rule_name);
        /* Use  real ptr as next  */
        confd_data_reply_next_key(tctx, &v, 1, (long) dl_next(first));
        return CONFD_OK;
    }
    if (next == -1) {  /* First key from empty DB, */
        return reteof(tctx);
    }
    else {
        if ((list = (Dlist*) next) == running_db) {
            /* we went all the way around */
            return reteof(tctx);
        }
        hp = (struct host*) list->val;
        CONFD_SET_STR(&v, hp->rule_name);
        /* Use  real ptr as next  */
        confd_data_reply_next_key(tctx, &v, 1, (long) dl_next(list));
        return CONFD_OK;
    }
}

static int host_num_instances(struct confd_trans_ctx *tctx,
                              confd_hkeypath_t *keypath)
{
    confd_value_t v;
    int cnt;
    Dlist *item;
    hcp_calls.num_instances++;

    cnt = 0;
    dl_traverse(item, running_db) {
        cnt++;
    }

    CONFD_SET_INT32(&v, cnt);
    confd_data_reply_value(tctx, &v);
    return CONFD_OK;
}

/* keypath here will look like */
/* /hosts/host{myhostname}/interfaces/interface */
static int host_get_elem(struct confd_trans_ctx *tctx,
                         confd_hkeypath_t *keypath)
{
    confd_value_t v;
    struct host *hp;
    Dlist *list = find_host(running_db, &(keypath->v[1][0]));
    hcp_calls.get_elem++;

    if (list ==  NULL) {
        confd_data_reply_not_found(tctx);
        return CONFD_OK;
    }
    hp = (struct host*) list->val;
    /* switch on xml elem tag */
    confd_data_reply_value(tctx, &v);
    return CONFD_OK;
}

/* assuming the name of the host being configured is "earth"     */
/* the keypaths we get here will be like :                       */
/* /hosts/host{earth}/interfaces/interface{eth0}/ip              */
/*   [6]  [5]   [4]     [3]        [2]     [1]   [0]             */
/* thus keypath->v[4][0] will refer to the name of the           */
/* host being configured                                         */
/* and  keypath->v[1][0] will refer to the name of the interface */
/* being configured                                              */

static int host_set_elem(struct confd_trans_ctx *tctx,
                         confd_hkeypath_t *keypath,
                         confd_value_t *newval)
{
    hcp_calls.set_elem++;
    return CONFD_ACCUMULATE;
}
static int host_create(struct confd_trans_ctx *tctx,
                       confd_hkeypath_t *keypath)
{
    hcp_calls.create++;
    return CONFD_ACCUMULATE;
}

static int host_delete(struct confd_trans_ctx *tctx,
                       confd_hkeypath_t *keypath)
{
    hcp_calls.remove++;
    return CONFD_ACCUMULATE;
}

static void init_cli()
{
    printf("> "); fflush(stdout);
    return;
}


/* Ultra primitive CLI which manipulates our "database" */
static void handle_stdin()
{

    char *tok;
    char line[BUFSIZ];
    int rval;
    static char currhost[255];
    char currprompt[255] = "> ";
    Dlist *hostlink;
    struct host *hp;
    confd_value_t v;
    char *sep = " \r\n";

    if ((rval = read(0, line, BUFSIZ)) <= 0) {
        fprintf(stderr, "EOF\n");
        read_stdin = 0;
        return;
    }
    line[rval] = 0;

    if ((tok = strtok(line, sep)) == NULL) {
        printf("%s", &currprompt[0]); fflush(stdout);
        return;
    }

    /* Show all database */
    if (strcmp(tok,"show") == 0) {
        if (currhost[0] == 0) {
            show_db(running_db);
        }
        else {
            CONFD_SET_STR(&v, currhost);
            if ((hostlink = find_host(running_db, &v)) != NULL) {
                show_host(hostlink);
            }
        }
    }
    else if (strcmp(tok,"quit") == 0) {
        exit(0);
    }

    if (currhost[0] != 0) {
        confd_value_t v;
        CONFD_SET_STR(&v, &currhost[0]);

        if ((hostlink = find_host(running_db, &v)) == NULL) {
            strcpy(currprompt, "> ");
            currhost[0] = 0;
        }
        else {
            hp = (struct host*) hostlink->val;
            sprintf(&currprompt[0], "[%s] > ", hp->rule_name);
        }
    }
    else {
        strcpy(currprompt, "> ");
    }

    printf("%s", &currprompt[0]);
    fflush(stdout);
    return;
}

/********************************************************************/

int main(int argc, char *argv[]) {
    int ctlsock;
    int workersock;
    struct sockaddr_in addr;
    struct mydata *md;
    int debuglevel = CONFD_TRACE;
    Dlist *list;
    int oc;             /* option character */
	pthread_t p_thread;
	int thr_id;
	int status;


	//////////////////IMTL CODE//////////////////////////////////////
	thr_id = pthread_create(&p_thread, NULL, Thread_processPacket, (void *)argv[1]);
	if (thr_id < 0)
	{
		perror("thread create error: ");
		exit(0);
	}
	//////////////////////////////////////////////////////////



    while ((oc = getopt(argc, argv, "qdtpci")) != -1) {
        switch (oc) {
        case 'q':
            debuglevel = CONFD_SILENT;
            break;
        case 'd':
            debuglevel = CONFD_DEBUG;
            break;
        case 't':
            debuglevel = CONFD_TRACE;
            break;
        case 'p':
            debuglevel = CONFD_PROTO_TRACE;
            break;
        case 'i':
            read_stdin = 0;
            break;
        default:
            fprintf(stderr, "usage: hosts [-qdtp]\n");
            exit(1);
        }
    }


    /* These are our transaction callbacks */
    trans.init = tr_init;
    trans.write_start = tr_writestart;
    trans.prepare = tr_prepare;
    trans.commit = tr_commit;
    trans.abort = tr_abort;
    trans.finish = tr_finish;


    /* And these are our db callbacks, we don't have the candidate */
    dbcbs.lock = lock;
    dbcbs.unlock = unlock;
    dbcbs.delete_config = delete_config;
    //dbcbs.add_checkpoint_running = add_checkpoint_running;
    dbcbs.del_checkpoint_running = del_checkpoint_running;
    dbcbs.activate_checkpoint_running = activate_checkpoint_running;

    /* And finallly these are our read/write callbacks for  */
    /* the database */
    host_cbks.get_elem = host_get_elem;
    host_cbks.get_next = host_get_next;
    host_cbks.num_instances = host_num_instances;
    host_cbks.set_elem = host_set_elem;
    host_cbks.create   = host_create;		//Create
    host_cbks.remove   = host_delete;
    strcpy(host_cbks.callpoint, "hcp");


    /* Init library  */
    confd_init("hosts_daemon", stderr, debuglevel);

    /* Initialize our simple database  */
    if ((list = restore("RUNNING.ckp")) != NULL) {
        printf("Restoring from checkpoint\n");
        unlink("RUNNING.ckp");
        running_db = list;
    }
    else if ((list = restore("RUNNING.db")) != NULL) {
        printf("Restoring from RUNNING.db\n");
        running_db = list;
    }
    else {
        printf("Starting with empty DB\n");
        running_db = new_dlist();
    }

    /* Initialize daemon context */
    if ((dctx = confd_init_daemon("hosts_daemon")) == NULL)
        confd_fatal("Failed to initialize confd\n");

    if ((ctlsock = socket(PF_INET, SOCK_STREAM, 0)) < 0 )
        confd_fatal("Failed to open ctlsocket\n");

	
//	addr.sin_addr.s_addr = inet_addr("10.0.0.200");	//IMTL
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr.sin_family = AF_INET;
    addr.sin_port = htons(CONFD_PORT);

    if (confd_load_schemas((struct sockaddr*)&addr,
                           sizeof (struct sockaddr_in)) != CONFD_OK)
        confd_fatal("Failed to load schemas from confd\n");

    /* Create the first control socket, all requests to */
    /* create new transactions arrive here */

    if (confd_connect(dctx, ctlsock, CONTROL_SOCKET, (struct sockaddr*)&addr,
                      sizeof (struct sockaddr_in)) < 0)
        confd_fatal("Failed to confd_connect() to confd \n");


    /* Also establish a workersocket, this is the most simple */
    /* case where we have just one ctlsock and one workersock */

    if ((workersock = socket(PF_INET, SOCK_STREAM, 0)) < 0 )
        confd_fatal("Failed to open workersocket\n");
    if (confd_connect(dctx, workersock, WORKER_SOCKET,(struct sockaddr*)&addr,
                      sizeof (struct sockaddr_in)) < 0)
        confd_fatal("Failed to confd_connect() to confd \n");


    /* Create a user datastructure and connect it to the */
    /* daemon struct so that we can always get to it */
    if ((md = dctx->d_opaque = (struct mydata*)
         calloc(1, sizeof(struct mydata))) == NULL)
        confd_fatal("Failed to malloc");
    md->ctlsock = ctlsock;
    md->workersock = workersock;


    confd_register_trans_cb(dctx, &trans);
    confd_register_db_cb(dctx, &dbcbs);

    /* we also need to register our read/write callbacks */

    if (confd_register_data_cb(dctx, &host_cbks) == CONFD_ERR)
        confd_fatal("Failed to register host cb \n");
    if (confd_register_data_cb(dctx, &iface_cbks) == CONFD_ERR)
        confd_fatal("Failed to register iface cb \n");

    if (confd_register_done(dctx) != CONFD_OK)
        confd_fatal("Failed to complete registration \n");

    /* First prompt */
    init_cli();

    while (1) {
        struct pollfd set[3];
        int ret;

        set[0].fd = ctlsock;
        set[0].events = POLLIN;
        set[0].revents = 0;

        set[1].fd = workersock;
        set[1].events = POLLIN;
        set[1].revents = 0;

        set[2].fd = 0;
        set[2].events = POLLIN;
        set[2].revents = 0;

        if (poll(&set[0], read_stdin?3:2, -1) < 0) {
            perror("Poll failed:");
            continue;
        }

        /* Check for I/O */
        if (set[0].revents & POLLIN) {
            if ((ret = confd_fd_ready(dctx, ctlsock)) == CONFD_EOF) {
                confd_fatal("Control socket closed\n");
            } else if (ret == CONFD_ERR && confd_errno != CONFD_ERR_EXTERNAL) {
                confd_fatal("Error on control socket request: %s (%d): %s\n",
                     confd_strerror(confd_errno), confd_errno, confd_lasterr());
            }
        }
        if (set[1].revents & POLLIN) {
            if ((ret = confd_fd_ready(dctx, workersock)) == CONFD_EOF) {
                confd_fatal("Worker socket closed\n");
            } else if (ret == CONFD_ERR && confd_errno != CONFD_ERR_EXTERNAL) {
                confd_fatal("Error on worker socket request: %s (%d): %s\n",
                     confd_strerror(confd_errno), confd_errno, confd_lasterr());
            }
        }
        if (read_stdin && (set[2].revents & POLLIN)) {
            handle_stdin();
        }
    }
}

/********************************************************************/
