#ifndef __HOSTS__
#define __HOSTS__

#include "../../Interfaces/nsf-sff-interface.h"

#endif
