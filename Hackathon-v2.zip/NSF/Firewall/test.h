#ifndef __MAIN__
#define __MAIN__

#include "../../Interfaces/nsf-sff-interface.h"

#endif
